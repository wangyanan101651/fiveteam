import React, { Component } from 'react';
import './Screen.css'

const className = 'Screen'
class Screen extends Component {
  render () {
    // const {children} = this.props
    return (
      <div className = {className}>
        Screendfg
        {/* {children} */}
      </div>
    )
  }
}

export default Screen

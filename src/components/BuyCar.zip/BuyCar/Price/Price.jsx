import React, { Component } from 'react';
import './Price.css'

const className = 'Price'
class Price extends Component {
  render () {
    // const {children} = this.props
    return (
      <div className = {className}>
        Pricedfg
        {/* {children} */}
      </div>
    )
  }
}

export default Price
